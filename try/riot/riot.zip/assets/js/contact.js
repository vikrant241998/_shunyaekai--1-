// (function ($) {
//     'use strict';

//     var form = $('.contact__form'),
//         message = $('.contact__msg'),
//         form_data;

//     // Success function
//     function done_func(response) {
//         message.fadeIn().removeClass('alert-danger').addClass('alert-success');
//         message.text(response);
//         setTimeout(function () {
//             message.fadeOut();
//         }, 2000);
//         form.find('input:not([type="submit"]), textarea').val('');
//     }

//     // fail function
//     function fail_func(data) {
//         message.fadeIn().removeClass('alert-success').addClass('alert-success');
//         message.text(data.responseText);
//         setTimeout(function () {
//             message.fadeOut();
//         }, 2000);
//     }
    
//     form.submit(function (e) {
//         e.preventDefault();
//         form_data = $(this).serialize();
//         $.ajax({
//             type: 'POST',
//             url: form.attr('action'),
//             data: form_data
//         })
//         .done(done_func)
//         .fail(fail_func);
//     });
    
// })(jQuery);



let errorMessage = document.getElementsByClassName("error");
var contactObj = {
  nameErr: false,
  emailErr: false,
  subjectErr:false,
  descriptionErr: false,
};
let Nameregex = /^[a-zA-Z ]+$/;
// name validation
let Name = document.getElementsByName("name")[0];
Name.onkeyup = function () {
  console.log("uiui")
  if (
    this.value.length >= 3 &&
    Nameregex.test(this.value) &&
    this.value.trim()
  ) {
    contactObj.nameErr = true;
    errorMessage[0].innerHTML = "";
  } else {
    errorMessage[0].innerHTML = "Please enter a valid name";
    contactObj.nameErr = false;
  }
};
// email validation
let email = document.getElementsByName("email")[0];
email.onkeyup = function () {
  var regex = /^\S+@\S+\.\S+$/;
  if (this.value.length >= 3 && regex.test(this.value) && this.value.trim()) {
    errorMessage[1].innerHTML = "";
    contactObj.emailErr = true;
  } else {
    errorMessage[1].innerHTML = "Please enter a valid email";
    contactObj.emailErr = false;
  }
};
// subject validation
let Subject = document.getElementsByName("subject")[0];
Subject.onkeyup = function () {
  if (
    this.value.length >= 3 &&
    Nameregex.test(this.value) &&
    this.value.trim()
  ) {
    contactObj.subjectErr = true;
    errorMessage[2].innerHTML = "";
  } else {
    errorMessage[2].innerHTML = "Please enter a valid subject";
    contactObj.subjectErr = false;
  }
};


// message validation
let Description = document.getElementsByName("message")[0];
Description.onkeyup = function () {
  var minLenght = 20;
  let regex = /^[a-zA-Z0-9., ]+$/;
  if (
    this.value.length >= minLenght &&
    regex.test(this.value) &&
    this.value.trim()
  ) {
    errorMessage[3].innerHTML = "";
    contactObj.descriptionErr = true;
  } else if (!regex.test(this.value)) {
    errorMessage[3].innerHTML = "please enter valid description";
    contactObj.descriptionErr = false;
  } else {
    errorMessage[3].innerHTML = "Message must be atleast 20 characters";
    contactObj.descriptionErr = false;
  }
};
// address
function contactFormSubmit(event) {
  event.preventDefault();
  console.log(contactObj)
  if (Object.values(contactObj).every((value) => value === true)) {
    // Create Message
    // let finalmessage = `Contact%20Form%20Details%20<br/>%20Name%20:%20${Name.value}%20<br/>%20Email%20:%20${email.value}%20<br/>%20Email%20:%20${email.value}%20<br/>%Subject%20:%20${Subject.value}%20<br/>%Message%20:%20${Description.value}%20<br/>`;
    let finalmessage = `contact-Form<br/> Name:${Name.value}<br/>Email:${email.value}<br/>Subject:${Subject.value}<br/>Message:${Description.value}`
    document.getElementById("submit").innerHTML = "PLEASE WAIT..";
    console.log(finalmessage);
    fetch(
     `https://mail.riotlearning.com/sendmail?msg=${finalmessage}&email=${email.value}`
    )
      .then((res) => res.json())
      .then(() => window.location.reload())
      .catch((error) => console.log(error));
  } else {
    console.log(contactObj.descriptionErr);
    if (contactObj.nameErr === false) {
      errorMessage[0].innerHTML = "Please fill in this field";
    }
    if (contactObj.emailErr === false) {
      errorMessage[1].innerHTML = "Please fill in this field";
    }
    if (contactObj.subjectErr === false) {
      errorMessage[2].innerHTML = "Please fill in this field";
    }
    if (contactObj.descriptionErr === false) {
      errorMessage[3].innerHTML = "Please fill in this field";
    }
   
  }
}
